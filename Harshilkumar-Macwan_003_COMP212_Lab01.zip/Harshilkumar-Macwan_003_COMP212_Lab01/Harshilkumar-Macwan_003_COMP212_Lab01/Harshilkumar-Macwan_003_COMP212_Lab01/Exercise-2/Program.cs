﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_2
{
    class Program
    {
        // Declare a delegate
        public delegate bool GradesPredicate(double d);
        static void Main(string[] args)
        {
            //Declaring an array of students grades 
            double[] studentGrade ={12.5,22.5,33.5,44.4,55.5,66.6,77.7,88.5,99.5,78.5};
            // calling GradesFilter method 
             GradesFilter(studentGrade, grade => grade>=50);
        }
        // this method takes two arguments and prints the result
        private static void GradesFilter(double[] grades, GradesPredicate gradesPredicate)
        { 
            foreach (double grade in grades)
                if (gradesPredicate(grade))
                    Console.Write(grade + ", ");
        }      
    }
}
