﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Harshilkumar_Macwan_003_COMP212_Lab01
{  
    class Program
    {
        public static void Main(string[] args)
        {   
            Func<String, String, String, String> testMinimun = Minimum;   // Assign Delegate
            Console.WriteLine($"Smallest of \"Hi\" , \"Hello\" and \"Howdy\" is {testMinimun("Hi", "Hello", "Howdy")}"); // call delegate

            Action<double,double,double> testAverage = AvgGrade; // Assign 2nd Delegate
            testAverage(35.12, 45.12, 55.12); // Call Delegate

            
        }
        // This mathod takes three string arguements and return the smallest
        private static string Minimum(string a, string b, string c)
        {
            if (a.Length <= b.Length && a.Length <= c.Length)
                return a;

            else if (b.Length <= a.Length && b.Length <= c.Length)
               return b;

            else
               return c;
        }
       // This method takes three Double arguement and return average of those three 
        private static void AvgGrade(double a, double b, double c)
        {
            double result= (a + b + c) / 3;
            Console.WriteLine($"Average of {a}, {b}, {c} is  {result}");
        }
      
    }
}
