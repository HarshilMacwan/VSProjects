﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Harshilkumar_Macwan_exercise1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            double cost=0;
            double discount = 0;
            double provincialTax = 0;
            string name = TbName.Text;
      
            if (CbFLossing.IsChecked == true)
            {
                cost += 20.00;
              
            }
            if (CbFilling.IsChecked == true)
            {
                cost += 75.00;
              
            }
            if (CbRootCanal.IsChecked == true)
            {
                cost += 150.00;
                
            }
            if (RdKid.IsChecked == true)
            {
                discount = 0.15;
            }
            if (RdSenior.IsChecked == true)
            {
                discount += 0.10;
            }
            if (CbProvince.SelectedIndex ==0)
            {
                provincialTax += 0.07;
            }
            if (CbProvince.SelectedIndex == 1)
            {
                provincialTax += 0.13;
            }
            if (CbProvince.SelectedIndex == 2)
            {
                provincialTax += 0.06;
            }
            double totalPrice = ((cost - (cost * discount)) + (cost * provincialTax));
            TbResults.Text = $"Name: {name}  Cost: {totalPrice}";
        }
    }
}
