﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Harshilkumar_Macwan_exercise2
{
    class Program
    {
        static void Main(string[] args)
        {
            Invoice[] DataInvoice = new Invoice[]
            {            
                new Invoice{PartNumber=87,PartDescription="Electric Sander",Quantity=7,Price=57.99M},
                new Invoice{PartNumber=24,PartDescription="Power Saw",Quantity=18,Price=99.99M},       
                new Invoice{PartNumber=7,PartDescription="Sledge Hammer",Quantity=11,Price=21.50M},                
                new Invoice{PartNumber=77,PartDescription="Hammer",Quantity=76,Price=11.99M},               
                new Invoice{PartNumber=39,PartDescription="Lawn Mower",Quantity=3,Price=79.50M},                
                new Invoice{PartNumber=68,PartDescription="Screw Driver",Quantity=106,Price=6.99M},                
                new Invoice{PartNumber=56,PartDescription="Jig Saw",Quantity=21,Price=11.00M}
            };
            var invoiceTotal =
               from invoice in DataInvoice
               let value = invoice.Price * invoice.Quantity
               orderby value descending
               select new { invoice.PartDescription, value };

            foreach (var item in invoiceTotal)
            {
                Console.WriteLine(item);
            }
            

            var highestPrice = DataInvoice.OrderByDescending(p => p.Price).First();
            Console.WriteLine("Part description of part with Highest Price: " + highestPrice.PartDescription);

            //average price of parts
            var averagePrice = DataInvoice.Average(p => p.Price);
            Console.WriteLine("Average Price of Parts: " + averagePrice);
            Console.ReadLine();
        }
       
    }
}
