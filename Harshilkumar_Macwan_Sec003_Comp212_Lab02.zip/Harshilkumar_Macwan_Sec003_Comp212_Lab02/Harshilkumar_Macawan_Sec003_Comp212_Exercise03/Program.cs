﻿using System;
using MyLinckedListLibrary;
namespace Harshilkumar_Macawan_Sec003_Comp212_Exercise03
{
    class Program
    {
        static void Main(string[] args)
        {
            var list = new List<int>();
            list.InsertAtFront(1);
            Console.WriteLine($"{list.GetLastNode()}");
            list.InsertAtBack(2);
            Console.WriteLine($"{list.GetLastNode()}");
            list.InsertAtBack(3);
            Console.WriteLine($"{list.GetLastNode()}");
            list.InsertAtBack(4);
            Console.WriteLine($"{list.GetLastNode()}");
            list.InsertAtBack(5);
            Console.WriteLine($"{list.GetLastNode()}");

            var list2 = new List<double>();
            list2.InsertAtFront(1.1);
            Console.WriteLine($"{list2.GetLastNode()}");
            list2.InsertAtBack(2.1);
            Console.WriteLine($"{list2.GetLastNode()}");
            list2.InsertAtBack(3.1);
            Console.WriteLine($"{list2.GetLastNode()}");
            list2.InsertAtBack(4.1);
            Console.WriteLine($"{list2.GetLastNode()}");
            list2.InsertAtBack(5.1);
            Console.WriteLine($"{list2.GetLastNode()}");
        }
    }
}
