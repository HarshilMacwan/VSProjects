﻿using System;

namespace Harshilkumar_Macwan_Sec003_Comp212_Exercise01
{
    class Program
    {
        static void Main(string[] args)
        {

            // DECLERING ARRAYS OF DIFFRENT TYPE
            double[] arrDouble = { 11.1, 12.1, 13.1, 14.1, 15.1, 16.1, 17.1, 18.1, 19.1, 20.1 };
            int[] arrInt = { 11, 21, 31, 41, 51, 61, 71, 81, 91, 101 };
            char[] arrChar = { 'A', 'E', 'I', 'O', 'U' };

            // checking search function

            Console.WriteLine($" 15.1 has index of {Search(arrDouble, 15.1)} in double array");
            Console.WriteLine($"81 has index of{Search(arrInt, 81)} in Int array");
            Console.WriteLine($"{Search(arrChar, 'A')}");
        }
        public static int Search<T>(T[] dataArray, T searchKey) where T : IComparable<T>
        {
            int result = -1; //initial result and also return result
            int i = 0; //this i will return the index at which searchkey matches the value in array.
            foreach (T data in dataArray)
            {
                i++;
                if (data.CompareTo(searchKey) == 0)
                {
                    result = i;
                    return result; //return the result
                }
            }
            return result;
        }
    }
}
