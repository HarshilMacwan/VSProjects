﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Harshilkumar_Macwan_Sec003_Comp212_Exercise02
{
    static class ExtentionForStringBuilder
    {
        public static int CountChars(this StringBuilder stringBuilder)
        {
            return stringBuilder.ToString().Length;
        }
    }
}
