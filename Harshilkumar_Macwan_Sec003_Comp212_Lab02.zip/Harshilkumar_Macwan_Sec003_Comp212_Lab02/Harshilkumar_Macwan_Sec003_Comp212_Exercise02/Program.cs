﻿using System;

namespace Harshilkumar_Macwan_Sec003_Comp212_Exercise02
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder("abcdefghijklmno   pqrstuvwxyz");
            Console.WriteLine(sb.CountChars());
            Console.ReadKey();
        }
    }
}
