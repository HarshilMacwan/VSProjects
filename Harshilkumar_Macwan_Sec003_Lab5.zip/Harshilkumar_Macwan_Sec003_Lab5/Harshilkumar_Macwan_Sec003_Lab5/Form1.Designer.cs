﻿namespace Harshilkumar_Macwan_Sec003_Lab5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.FactorialOutputLb = new System.Windows.Forms.Label();
            this.FactorialCalculateBtn = new System.Windows.Forms.Button();
            this.FactorialTb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.OddEvenOutputLb = new System.Windows.Forms.Label();
            this.OddEvenCheckBtn = new System.Windows.Forms.Button();
            this.OddEvenTb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ResultsBox = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.DisplayBtn = new System.Windows.Forms.Button();
            this.SearchBtn = new System.Windows.Forms.Button();
            this.GenrateValuesBtn = new System.Windows.Forms.Button();
            this.HighIndexTb = new System.Windows.Forms.TextBox();
            this.LowIndexTb = new System.Windows.Forms.TextBox();
            this.SearchInputTb = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.GenratedValuesList = new System.Windows.Forms.ListBox();
            this.CharsRadio = new System.Windows.Forms.RadioButton();
            this.DoublesRadio = new System.Windows.Forms.RadioButton();
            this.IntegerRadio = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.FactorialOutputLb);
            this.groupBox1.Controls.Add(this.FactorialCalculateBtn);
            this.groupBox1.Controls.Add(this.FactorialTb);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(13, 43);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(437, 167);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "(1) Calculate Asynchronously";
            // 
            // FactorialOutputLb
            // 
            this.FactorialOutputLb.Location = new System.Drawing.Point(157, 105);
            this.FactorialOutputLb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.FactorialOutputLb.Name = "FactorialOutputLb";
            this.FactorialOutputLb.Size = new System.Drawing.Size(199, 28);
            this.FactorialOutputLb.TabIndex = 3;
            // 
            // FactorialCalculateBtn
            // 
            this.FactorialCalculateBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FactorialCalculateBtn.Location = new System.Drawing.Point(31, 105);
            this.FactorialCalculateBtn.Margin = new System.Windows.Forms.Padding(4);
            this.FactorialCalculateBtn.Name = "FactorialCalculateBtn";
            this.FactorialCalculateBtn.Size = new System.Drawing.Size(100, 28);
            this.FactorialCalculateBtn.TabIndex = 2;
            this.FactorialCalculateBtn.Text = "Calculate";
            this.FactorialCalculateBtn.UseVisualStyleBackColor = true;
            this.FactorialCalculateBtn.Click += new System.EventHandler(this.FactorialCalculateBtn_Click);
            // 
            // FactorialTb
            // 
            this.FactorialTb.Location = new System.Drawing.Point(181, 49);
            this.FactorialTb.Margin = new System.Windows.Forms.Padding(4);
            this.FactorialTb.Name = "FactorialTb";
            this.FactorialTb.Size = new System.Drawing.Size(132, 23);
            this.FactorialTb.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 54);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Get Factorial Of : ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.OddEvenOutputLb);
            this.groupBox2.Controls.Add(this.OddEvenCheckBtn);
            this.groupBox2.Controls.Add(this.OddEvenTb);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(13, 252);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(437, 175);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "(2) Check for Even/Odd";
            // 
            // OddEvenOutputLb
            // 
            this.OddEvenOutputLb.Location = new System.Drawing.Point(236, 116);
            this.OddEvenOutputLb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.OddEvenOutputLb.Name = "OddEvenOutputLb";
            this.OddEvenOutputLb.Size = new System.Drawing.Size(199, 28);
            this.OddEvenOutputLb.TabIndex = 4;
            // 
            // OddEvenCheckBtn
            // 
            this.OddEvenCheckBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OddEvenCheckBtn.Location = new System.Drawing.Point(8, 116);
            this.OddEvenCheckBtn.Margin = new System.Windows.Forms.Padding(4);
            this.OddEvenCheckBtn.Name = "OddEvenCheckBtn";
            this.OddEvenCheckBtn.Size = new System.Drawing.Size(220, 28);
            this.OddEvenCheckBtn.TabIndex = 2;
            this.OddEvenCheckBtn.Text = "Check for Even or Odd";
            this.OddEvenCheckBtn.UseVisualStyleBackColor = true;
            this.OddEvenCheckBtn.Click += new System.EventHandler(this.OddEvenCheckBtn_Click);
            // 
            // OddEvenTb
            // 
            this.OddEvenTb.Location = new System.Drawing.Point(181, 57);
            this.OddEvenTb.Margin = new System.Windows.Forms.Padding(4);
            this.OddEvenTb.Name = "OddEvenTb";
            this.OddEvenTb.Size = new System.Drawing.Size(132, 23);
            this.OddEvenTb.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 60);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Input Number : ";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ResultsBox);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.DisplayBtn);
            this.groupBox3.Controls.Add(this.SearchBtn);
            this.groupBox3.Controls.Add(this.GenrateValuesBtn);
            this.groupBox3.Controls.Add(this.HighIndexTb);
            this.groupBox3.Controls.Add(this.LowIndexTb);
            this.groupBox3.Controls.Add(this.SearchInputTb);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.GenratedValuesList);
            this.groupBox3.Controls.Add(this.CharsRadio);
            this.groupBox3.Controls.Add(this.DoublesRadio);
            this.groupBox3.Controls.Add(this.IntegerRadio);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(458, 37);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(859, 405);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "(3) Display List of Values and Search";
            // 
            // ResultsBox
            // 
            this.ResultsBox.FormattingEnabled = true;
            this.ResultsBox.ItemHeight = 17;
            this.ResultsBox.Location = new System.Drawing.Point(181, 262);
            this.ResultsBox.Margin = new System.Windows.Forms.Padding(4);
            this.ResultsBox.Name = "ResultsBox";
            this.ResultsBox.Size = new System.Drawing.Size(436, 106);
            this.ResultsBox.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(177, 241);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(301, 17);
            this.label6.TabIndex = 17;
            this.label6.Text = "Output Of Values between Low and High";
            // 
            // DisplayBtn
            // 
            this.DisplayBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DisplayBtn.Location = new System.Drawing.Point(507, 145);
            this.DisplayBtn.Margin = new System.Windows.Forms.Padding(4);
            this.DisplayBtn.Name = "DisplayBtn";
            this.DisplayBtn.Size = new System.Drawing.Size(100, 28);
            this.DisplayBtn.TabIndex = 16;
            this.DisplayBtn.Text = "Display";
            this.DisplayBtn.UseVisualStyleBackColor = true;
       
            // 
            // SearchBtn
            // 
            this.SearchBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchBtn.Location = new System.Drawing.Point(507, 107);
            this.SearchBtn.Margin = new System.Windows.Forms.Padding(4);
            this.SearchBtn.Name = "SearchBtn";
            this.SearchBtn.Size = new System.Drawing.Size(100, 28);
            this.SearchBtn.TabIndex = 15;
            this.SearchBtn.Text = "Search";
            this.SearchBtn.UseVisualStyleBackColor = true;
            this.SearchBtn.Click += new System.EventHandler(this.SearchBtn_Click);
            // 
            // GenrateValuesBtn
            // 
            this.GenrateValuesBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenrateValuesBtn.Location = new System.Drawing.Point(436, 50);
            this.GenrateValuesBtn.Margin = new System.Windows.Forms.Padding(4);
            this.GenrateValuesBtn.Name = "GenrateValuesBtn";
            this.GenrateValuesBtn.Size = new System.Drawing.Size(171, 28);
            this.GenrateValuesBtn.TabIndex = 14;
            this.GenrateValuesBtn.Text = "Generate Values";
            this.GenrateValuesBtn.UseVisualStyleBackColor = true;
            this.GenrateValuesBtn.Click += new System.EventHandler(this.GenrateValuesBtn_Click);
            // 
            // HighIndexTb
            // 
            this.HighIndexTb.Location = new System.Drawing.Point(321, 190);
            this.HighIndexTb.Margin = new System.Windows.Forms.Padding(4);
            this.HighIndexTb.Name = "HighIndexTb";
            this.HighIndexTb.Size = new System.Drawing.Size(132, 23);
            this.HighIndexTb.TabIndex = 12;
            // 
            // LowIndexTb
            // 
            this.LowIndexTb.Location = new System.Drawing.Point(321, 150);
            this.LowIndexTb.Margin = new System.Windows.Forms.Padding(4);
            this.LowIndexTb.Name = "LowIndexTb";
            this.LowIndexTb.Size = new System.Drawing.Size(132, 23);
            this.LowIndexTb.TabIndex = 11;
            // 
            // SearchInputTb
            // 
            this.SearchInputTb.Location = new System.Drawing.Point(321, 107);
            this.SearchInputTb.Margin = new System.Windows.Forms.Padding(4);
            this.SearchInputTb.Name = "SearchInputTb";
            this.SearchInputTb.Size = new System.Drawing.Size(132, 23);
            this.SearchInputTb.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(173, 193);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "Input High Index";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(173, 150);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Input Low Index";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(155, 111);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Input Value for Search :";
            // 
            // GenratedValuesList
            // 
            this.GenratedValuesList.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenratedValuesList.FormattingEnabled = true;
            this.GenratedValuesList.ItemHeight = 17;
            this.GenratedValuesList.Location = new System.Drawing.Point(29, 105);
            this.GenratedValuesList.Margin = new System.Windows.Forms.Padding(4);
            this.GenratedValuesList.Name = "GenratedValuesList";
            this.GenratedValuesList.Size = new System.Drawing.Size(92, 276);
            this.GenratedValuesList.TabIndex = 6;
            // 
            // CharsRadio
            // 
            this.CharsRadio.AutoSize = true;
            this.CharsRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CharsRadio.Location = new System.Drawing.Point(283, 50);
            this.CharsRadio.Margin = new System.Windows.Forms.Padding(4);
            this.CharsRadio.Name = "CharsRadio";
            this.CharsRadio.Size = new System.Drawing.Size(66, 21);
            this.CharsRadio.TabIndex = 5;
            this.CharsRadio.TabStop = true;
            this.CharsRadio.Text = "Chars";
            this.CharsRadio.UseVisualStyleBackColor = true;
            // 
            // DoublesRadio
            // 
            this.DoublesRadio.AutoSize = true;
            this.DoublesRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DoublesRadio.Location = new System.Drawing.Point(160, 49);
            this.DoublesRadio.Margin = new System.Windows.Forms.Padding(4);
            this.DoublesRadio.Name = "DoublesRadio";
            this.DoublesRadio.Size = new System.Drawing.Size(81, 21);
            this.DoublesRadio.TabIndex = 4;
            this.DoublesRadio.TabStop = true;
            this.DoublesRadio.Text = "Doubles";
            this.DoublesRadio.UseVisualStyleBackColor = true;
            // 
            // IntegerRadio
            // 
            this.IntegerRadio.AutoSize = true;
            this.IntegerRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IntegerRadio.Location = new System.Drawing.Point(29, 49);
            this.IntegerRadio.Margin = new System.Windows.Forms.Padding(4);
            this.IntegerRadio.Name = "IntegerRadio";
            this.IntegerRadio.Size = new System.Drawing.Size(80, 21);
            this.IntegerRadio.TabIndex = 0;
            this.IntegerRadio.Text = "Integers";
            this.IntegerRadio.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1136, 450);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button FactorialCalculateBtn;
        private System.Windows.Forms.TextBox FactorialTb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button OddEvenCheckBtn;
        private System.Windows.Forms.TextBox OddEvenTb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox ResultsBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button DisplayBtn;
        private System.Windows.Forms.Button SearchBtn;
        private System.Windows.Forms.Button GenrateValuesBtn;
        private System.Windows.Forms.TextBox HighIndexTb;
        private System.Windows.Forms.TextBox LowIndexTb;
        private System.Windows.Forms.TextBox SearchInputTb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox GenratedValuesList;
        private System.Windows.Forms.RadioButton CharsRadio;
        private System.Windows.Forms.RadioButton DoublesRadio;
        private System.Windows.Forms.RadioButton IntegerRadio;
        private System.Windows.Forms.Label FactorialOutputLb;
        private System.Windows.Forms.Label OddEvenOutputLb;
    }
}

