﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Harshilkumar_Macwan_Sec003_Lab5
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

        }
        //First group box
        private async void FactorialCalculateBtn_Click(object sender, EventArgs e)
        {
            if (FactorialTb.Text != "")
            {
                try
                {
                    long number = 0;
                    bool NumberEntered = long.TryParse(FactorialTb.Text, out number);
                    await Task.WhenAll(Task.Run(() => Factorial(number)));
                    FactorialOutputLb.Visible = true;
                    FactorialOutputLb.Text = Factorial(number).ToString();
                }
                catch
                {
                    FactorialTb.Text = "";
                    MessageBox.Show("Invalid input value");
                }
            }
            else
            {

                MessageBox.Show("No input values found");
            }

        }
        private long Factorial(long num)
        {
            if (num == 1 || num == 2)
            {
                return num;
            }
            else
            {
                return num * Factorial(num - 1);
            }
        }

        //second group box
        public delegate bool NumberPredicate(int number);

        Func<int, bool> IsOdd = x => x % 2 == 1;
        Func<int, bool> IsEven = x => x % 2 == 0;

        private void OddEvenCheckBtn_Click(object sender, EventArgs e)
        {
            if (OddEvenTb.Text != null)
            {
                int num = Convert.ToInt32(OddEvenTb.Text);

                try
                {

                    if (IsOdd(num))
                    {
                        OddEvenOutputLb.Text = "Odd";
                    }
                    else if (IsEven(num))
                    {
                        OddEvenOutputLb.Text = "Even";
                    }

                }
                catch
                {
                    MessageBox.Show("Please enter valid value!");
                }
            }
            else
            {
                MessageBox.Show("No input value found");

            }
        }


        //third group box
        private void GenrateValuesBtn_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            GenratedValuesList.Items.Clear();
            if (IntegerRadio.Checked)
            {
                for (int i = 0; i < 10; i++)
                {
                    double randomNum = r.Next(10, 99);
                    GenratedValuesList.Items.Add(randomNum);
                }
            }
            else if (DoublesRadio.Checked)
            {
                for (int i = 0; i < 10; i++)
                {
                    double randomNum = Math.Round(r.NextDouble() * (100.0 - 1.0) + 1.0, 2);
                    GenratedValuesList.Items.Add(randomNum);
                }
            }
            else if (CharsRadio.Checked)
            {
                string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                for (int i = 0; i < 10; i++)
                {
                    int randomNum = r.Next(1, 26);
                    GenratedValuesList.Items.Add(chars[randomNum]);
                }
            }
            else
            {
                MessageBox.Show("Please check a type of items for the Listbox");
            }
        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            if (SearchInputTb.Text != null)
            {

                try
                {
                    List<object> listValues = new List<object>();

                    for (int i = 0; i < GenratedValuesList.Items.Count; i++)
                    {
                        listValues.Add(GenratedValuesList.Items[i]);
                    }

                    double index = SearchData(listValues, SearchInputTb.Text);


                    if (index == -1)
                    {
                        MessageBox.Show("Value Not found");
                    }
                    else
                    {
                        MessageBox.Show("Element found at " + index.ToString() + " position");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);

                }

            }
            else
            {
                MessageBox.Show("Sorry..!! Nothing to search");
            }

        }
        //private void DisplayBtn_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        int lowIndex = Convert.ToInt32(LowIndexTb.Text);
        //        int highIndex = Convert.ToInt32(HighIndexTb.Text);

        //        List<object> listValues = new List<object>();

        //        for (int i = 0; i < GenratedValuesList.Items.Count; i++)
        //        {
        //            listValues.Add(GenratedValuesList.Items[i]);
        //        }

        //        String result = PrintData(listValues, lowIndex, highIndex);
        //        ResultsBox.Text = result;

        //    }
        //    catch (Exception)
        //    {
        //        MessageBox.Show("Invalid Low or High index values");
        //        LowIndexTb.Text = "";
        //        LowIndexTb.Text = "";
        //    }
        //}

        private static int SearchData<T>(List<T> ArrayList, object searchValue) //searching the value in  array
        {

            int i = 0;
            foreach (var e in ArrayList)
            {
                i++;
                if (searchValue.ToString() == e.ToString())
                {
                    return i;
                }
            }
            return -1;

        }

        //private static void PrintData<T>(List<T> value, T lowIndex, T highIndex)
        //{
        //    var listInt = new List<T>();
        //    foreach (var item in value)
        //    {
        //        if(lowIndex.CompareTo(item)< item && item<highIndex)
        //        {
        //            listInt.Add(item);
        //        }
        //    }
        //}
    }
}
    

